.. _context:

*************
Cairo Context
*************

.. currentmodule:: cairo

class Context()
===============

.. autoclass:: Context
    :members:
    :undoc-members:

    .. automethod:: __init__
